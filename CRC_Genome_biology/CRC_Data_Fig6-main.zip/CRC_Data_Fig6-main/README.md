# CRC_Data_Fig6
Codes and data to reproduce the Continuous subtype scoring across cell type of the CRC single cell project

Refining colorectal cancer classification and clinical stratification through a single-cell atlas
https://genomebiology.biomedcentral.com/articles/10.1186/s13059-022-02677-z/figures/6

